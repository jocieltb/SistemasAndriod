package com.example.cadastrofilmes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnAdd;
    RecyclerView rclFilmes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAdd = findViewById(R.id.btnAdd);
        rclFilmes = findViewById(R.id.rclFilmes);

        // cada vez que carregar esta activity, devemos limpar
        // a lista local, e carregar os dados do banco, para
        // evitar registros duplicados na lista.

        if(ListaFilmes.getLista().size() > 0){
            ListaFilmes.getLista().clear();;
        }

        FilmeDAO dao = new FilmeDAO(MainActivity.this);
        try {
            dao.listarFilmes();
        }catch (Exception e) {
            e.printStackTrace();
        }

        if(ListaFilmes.getLista().size() == 0){
            ListaFilmes.gerarLista();
        }

        FilmeAdapter filmeAdapter = new FilmeAdapter(ListaFilmes.getLista(), MainActivity.this);

        rclFilmes.setAdapter(filmeAdapter);

        RecyclerView.LayoutManager meuLayout = new LinearLayoutManager(
                MainActivity.this, LinearLayoutManager.VERTICAL, false
        );
        rclFilmes.setLayoutManager(meuLayout);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, CadastroFilmes.class));
            }
        });

    }
}
