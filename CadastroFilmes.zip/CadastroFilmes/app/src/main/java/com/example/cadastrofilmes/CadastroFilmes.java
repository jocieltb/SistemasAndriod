package com.example.cadastrofilmes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CadastroFilmes extends AppCompatActivity {

    EditText edtTitulo;
    EditText edtAno;
    EditText edtDiretor;
    EditText edtGenero;
    Button btnSalvar;

    String titulo;
    String direto;
    String ano;
    String genero;
    String msg; // posteriormente exibir mensagem de sucesso ou erro
    FilmeDAO dao; //

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_filmes);

        edtTitulo = findViewById(R.id.edtTitulo);
        edtAno = findViewById(R.id.edtAno);
        edtDiretor = findViewById(R.id.edtDiretor);
        edtGenero = findViewById(R.id.edtGenero);
        btnSalvar = findViewById(R.id.btnSalvar);

        dao = new FilmeDAO(CadastroFilmes.this);


        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try{

                    String titulo = edtTitulo.getText().toString();
                    String ano = edtAno.getText().toString();
                    String diretor = edtDiretor.getText().toString();
                    String genero = edtGenero.getText().toString();

                    Filme f = new Filme(titulo, ano, diretor,genero);

                    if (dao.salvar(f)){
                        msg = "Filme cadastrado com sucesso";
                    } else{
                        msg = "Erro ao cadastrar filme";
                    }

                    Toast.makeText(CadastroFilmes.this, msg, Toast.LENGTH_SHORT).show();

                    edtTitulo.setText("");
                    edtAno.setText("");
                    edtDiretor.setText("");
                    edtGenero.setText("");

                    startActivity(new Intent(CadastroFilmes.this, MainActivity.class));

                }
                catch (Exception e){
                    Toast.makeText(CadastroFilmes.this, "Erro ao cadastrar filme...", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
}
