package com.example.cadastrofilmes;

import java.io.File;
import java.util.ArrayList;

public class ListaFilmes {

    private static ArrayList<Filme> listaFilmes = new ArrayList<>();

    public static void addFilme(Filme f){

        listaFilmes.add(f);
    }

    public static ArrayList<Filme> getLista(){

        return listaFilmes;
    }

    public static Filme getFilme(int index){
        return listaFilmes.get(index);
    }

    public static void gerarLista(){

      listaFilmes.add(new Filme("Matrix", "1999", "Lana Wachowski, Lilly Wachowski","Ação, Ficção científica"));
      listaFilmes.add(new Filme("Armageddon", "1998", "Michael Bay","Ação, Ficção científica"));
      listaFilmes.add(new Filme("Presságio", "2009", "Alex Proyas","Suspense, Fantasia"));
      listaFilmes.add(new Filme("No Limite do Amanhã", "2014", "Doug Liman","Ação, Ficção científica"));
      listaFilmes.add(new Filme("O Preço do Amanhã", "2011", "Andrew Niccol","Ficção científica, Suspense"));
      listaFilmes.add(new Filme("Truque de Mestre", "2013", "Louis Leterrier","Suspense, Policial"));
    }

}
