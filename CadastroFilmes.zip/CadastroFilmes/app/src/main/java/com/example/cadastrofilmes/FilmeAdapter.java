package com.example.cadastrofilmes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FilmeAdapter extends RecyclerView.Adapter {

    private ArrayList<Filme> listaFilmes;

    private Context context;

    public FilmeAdapter(ArrayList<Filme> listaFilmes, Context context) {
        this.listaFilmes = listaFilmes;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.celula_filme, parent, false);

        FilmeViewHolder filmeViewHolder = new FilmeViewHolder(view);

        return filmeViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        FilmeViewHolder filmeViewHolder = (FilmeViewHolder) holder;

        filmeViewHolder.txtTitulo.setText(listaFilmes.get(position).getTitulo());
        filmeViewHolder.txtAno.setText(listaFilmes.get(position).getAno());
        filmeViewHolder.txtDiretor.setText(listaFilmes.get(position).getDiretor());
        filmeViewHolder.txtGereno.setText(listaFilmes.get(position).getGenero());
    }

    @Override
    public int getItemCount() {
        return listaFilmes.size();
    }
}
