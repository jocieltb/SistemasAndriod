package com.example.cadastrofilmes;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class DBGateway {

    //static somenta a essa class manipula uma variavel static
    //Instancia a base de dados
    private static DBGateway gateway;

    private SQLiteDatabase db;

    public DBGateway(Context context) {
        DBHelper helper = new DBHelper(context);
        db = helper.getWritableDatabase();
    }
    //retorna uma conexão ativa
    public static DBGateway getInstance(Context context){
        if (gateway == null){
            gateway = new DBGateway(context);
        }

        return gateway;
    }
    //retorna qual base de dados está sendo acessada
    public SQLiteDatabase getDatabase(){
        return this.db;
    }

}
