package com.example.cadastrofilmes;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FilmeViewHolder extends RecyclerView.ViewHolder {

    TextView txtTitulo;
    TextView txtAno;
    TextView txtDiretor;
    TextView txtGereno;

    public FilmeViewHolder (@NonNull View itemView){
        super(itemView);

        txtTitulo = itemView.findViewById(R.id.txtTitulo);
        txtAno = itemView.findViewById(R.id.txtAno);
        txtDiretor = itemView.findViewById(R.id.txtDiretor);
        txtGereno = itemView.findViewById(R.id.txtGenero);
    }
}
