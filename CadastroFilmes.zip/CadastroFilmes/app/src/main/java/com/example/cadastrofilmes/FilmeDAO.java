package com.example.cadastrofilmes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

public class FilmeDAO {

    private DBGateway gateway;

    public FilmeDAO(Context context){

        gateway = DBGateway.getInstance(context);
    }

    public boolean salvar(Filme f){
        //Criar ContetValues (similar a um Bandle)
        ContentValues values = new ContentValues();

        values.put(DBHelper.TITULO, f.getTitulo());
        values.put(DBHelper.DIRETOR, f.getDiretor());
        values.put(DBHelper.ANO, f.getAno());
        values.put(DBHelper.GENERO, f.getGenero());

        long result = gateway.getDatabase().insert(
                DBHelper.TABELA, null, values
        );

        /*
            'result' precisa ser 'long', pois o retorno de um comando sql numa base de dados SQLite e sempre 'long'.

            Acessamos nossa conexão com o banco(gateway);
            Recebemos a informação de qual banco estamos conecatados(getDatabase())
            Informamos que iremos fazer4 um INSErt Into em alguma tabela do banco rebebido:
                O primeiro argumento é o nome da tabela;
                segundo argumento, por padrão é null;
                terceiro argumento são os valores que iremos inserir (values).
         */
        if (result > 0){
            return true; //Cadastrou com sucesso
        }

        return false; //não foi possível cadastrar
    }

    public void listarFilmes(){

        //Criar comando sql
        String sql = "SELECT * fROM " + DBHelper.TABELA;

        //Criar cursor(uma especie de ponteiro que ira percorre
        //todos os dados de uma tabela existente no banco de dados

        Cursor cursor = gateway.getDatabase().rawQuery(sql, null);

        try {
            //mover cursor para o inicio da tabela proveniente do SELECT
            cursor.moveToFirst();

            //Enquanto hoverem linhas para percorrer na tabela

            while (cursor != null){
                String titulo = cursor.getString(cursor.getColumnIndex(DBHelper.TITULO));
                String diretor = cursor.getString(cursor.getColumnIndex(DBHelper.DIRETOR));
                String ano = cursor.getString(cursor.getColumnIndex(DBHelper.ANO));
                String genero = cursor.getString(cursor.getColumnIndex(DBHelper.GENERO));

                //armazenar variaveis locais no objeto "f"

                Filme f = new Filme(titulo, diretor, ano, genero);

                ListaFilmes.addFilme(f);

                cursor.moveToNext();

            } // fim 'while'

            //fechar cursor após ter percorrido todos os valores
            cursor.close();


        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
