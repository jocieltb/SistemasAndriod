package com.example.cadastrofilmes;

public class Filme {

    private String Titulo;

    private String Ano;

    private String Diretor;

    private String Genero;

    public Filme(String titulo, String ano, String diretor, String genero) {
        Titulo = titulo;
        Ano = ano;
        Diretor = diretor;
        Genero = genero;
    }

    public String getTitulo() {
        return Titulo;
    }

    public void setTitulo(String titulo) {
        Titulo = titulo;
    }

    public String getAno() {
        return Ano;
    }

    public void setAno(String ano) {
        Ano = ano;
    }

    public String getDiretor() {
        return Diretor;
    }

    public void setDiretor(String diretor) {
        Diretor = diretor;
    }

    public String getGenero() {
        return Genero;
    }

    public void setGenero(String genero) {
        Genero = genero;
    }
}
