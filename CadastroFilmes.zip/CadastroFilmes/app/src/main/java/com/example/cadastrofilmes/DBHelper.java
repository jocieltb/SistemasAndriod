package com.example.cadastrofilmes;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    //Constantes que definem nome do banco, tabela e campos

    public static final String DB = "filmes_DB";

    public static final String TABELA = "filmes";

    //Os campos abaixo devem ter relação com o tipo de dados que
    //irar salvar na sua tabela

    public  static final String ID = "id_filme"; //chave primaria

    public  static final String TITULO = "titulo";

    public  static final String DIRETOR = "diretor";

    public  static final String ANO = "ano";

    public  static final String GENERO = "genero";

    public  static final int VERSAO = 1;

    public DBHelper(@Nullable Context context) {
        super(context, DB, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //Criar Tabela
        String sql = "CREATE TABLE IF NOT EXISTS " +
                TABELA + " ( " +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                TITULO + " VARCHAR, " +
                DIRETOR + " VARCHAR, " +
                ANO + " VARCHAR, " +
                GENERO + " VARCHAR);";

        db.execSQL(sql);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE " + TABELA);
        onCreate(db);
    }
}
