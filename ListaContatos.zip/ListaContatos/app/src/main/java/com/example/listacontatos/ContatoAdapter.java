package com.example.listacontatos;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ContatoAdapter extends RecyclerView.Adapter {
    //Dois dados fundamentais para o Adapter:
    //Fonte de dados
    private ArrayList<Contato> listaContatos;
    //Contexto
    private Context context;

    public ContatoAdapter(ArrayList<Contato> listaContatos, Context context) {
        this.listaContatos = listaContatos;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Determinar o layout de cada celula do holder na view
        // Informamos o contexto em que será inserida aesta recycle list e qual o arquivo xml responsavel
        // pelo layout de cada celula (no nosso exemplo, é a celula.xml)

        View view = LayoutInflater.from(context).inflate(R.layout.celula, parent, false);

        ContatoViewHolder contatoViewHolder = new ContatoViewHolder(view);

        return contatoViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        ContatoViewHolder contatoViewHolder = (ContatoViewHolder) holder;
        contatoViewHolder.txtNome.setText(listaContatos.get(position).getNome());
        contatoViewHolder.txtFone.setText(listaContatos.get(position).getFone());
        contatoViewHolder.txtEmail.setText(listaContatos.get(position).getEmail());
    }

    @Override
    public int getItemCount() {
        return listaContatos.size();
    }
}
