package com.example.listacontatos;

public class Contato {

    private String Nome;
    private String Fone;
    private String Email;

    public Contato(String nome, String fone, String email) {
        Nome = nome;
        Fone = fone;
        Email = email;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getFone() {
        return Fone;
    }

    public void setFone(String fone) {
        Fone = fone;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }
}
