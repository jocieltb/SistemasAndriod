package com.example.listacontatos;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    Button btnAdd;
    RecyclerView rclContatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAdd = findViewById(R.id.btnAdd);
        rclContatos = findViewById(R.id.rclContato);

        if(ListaContatos.getLista().size() == 0){
            ListaContatos.gerarLista();
        }

        ContatoAdapter contatoAdapter = new ContatoAdapter(
            ListaContatos.getLista(), MainActivity.this
        );

        rclContatos.setAdapter(contatoAdapter);

        RecyclerView.LayoutManager meuLayout = new LinearLayoutManager(
                MainActivity.this,
                LinearLayoutManager.VERTICAL,
                false
        );

        rclContatos.setLayoutManager(meuLayout);
    }
}
