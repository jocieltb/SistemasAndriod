package com.example.listacontatos;

import java.util.ArrayList;

public class ListaContatos {

    private static ArrayList<Contato> listaContatos = new ArrayList<>();

    public static void addContato(Contato c){
        listaContatos.add(c);
    }

    public static ArrayList<Contato> getLista(){
        return listaContatos;
    }

    public static Contato getContato(int index){
        return listaContatos.get(index);
    }

    public static void gerarLista(){
        listaContatos.add(new Contato("João Silva", "(41) 99552 4152", "joao@gmail.com"));
        listaContatos.add(new Contato("Daniele Barros", "(41) 98572 4252", "daniellebr@gmail.com"));
        listaContatos.add(new Contato("Fernanda Santos", "(41) 97551 4172", "fsantos@gmail.com"));
        listaContatos.add(new Contato("Keyla Santana", "(41) 97452 3122", "keylast@gmail.com"));
        listaContatos.add(new Contato("Daniel", "(41) 98152 3252", "danielst@gmail.com"));
        listaContatos.add(new Contato("João Silva", "(41) 99552 4152", "joao@gmail.com"));
        listaContatos.add(new Contato("Daniele Barros", "(41) 98572 4252", "daniellebr@gmail.com"));
        listaContatos.add(new Contato("Fernanda Santos", "(41) 97551 4172", "fsantos@gmail.com"));
        listaContatos.add(new Contato("Keyla Santana", "(41) 97452 3122", "keylast@gmail.com"));
        listaContatos.add(new Contato("Daniel", "(41) 98152 3252", "danielst@gmail.com"));
        listaContatos.add(new Contato("João Silva", "(41) 99552 4152", "joao@gmail.com"));
        listaContatos.add(new Contato("Daniele Barros", "(41) 98572 4252", "daniellebr@gmail.com"));
        listaContatos.add(new Contato("Fernanda Santos", "(41) 97551 4172", "fsantos@gmail.com"));
        listaContatos.add(new Contato("Keyla Santana", "(41) 97452 3122", "keylast@gmail.com"));
        listaContatos.add(new Contato("Daniel", "(41) 98152 3252", "danielst@gmail.com"));
    }


}
