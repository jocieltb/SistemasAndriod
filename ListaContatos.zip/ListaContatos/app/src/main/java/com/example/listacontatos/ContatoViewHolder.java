package com.example.listacontatos;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ContatoViewHolder extends RecyclerView.ViewHolder {

    TextView txtNome;
    TextView txtFone;
    TextView txtEmail;

    public ContatoViewHolder(@NonNull View itemView) {
        super(itemView);

        txtNome = itemView.findViewById(R.id.txtNome);
        txtFone = itemView.findViewById(R.id.txtFone);
        txtEmail = itemView.findViewById(R.id.txtEmail);
    }
}
