package com.example.calculadora20;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txtVisor;

    String textoVisor;
    String op;
    Float numeroAtual = 0f;
    Float numeroAnterior = 0f;
    Float resultado = 0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtVisor = findViewById(R.id.txtVisor);
    }

    public void btnNumero(View view){
        Button btnNumero = (Button) view;
        String numero = btnNumero.getText().toString();
        textoVisor = txtVisor.getText().toString();

        if(textoVisor.equals("0")){
            if(numero.equals("0")){
                textoVisor = "0";
            } else {
                textoVisor = numero;
            }
        } else {
            textoVisor += numero;
        }
        txtVisor.setText(textoVisor);

        numeroAtual = Float.parseFloat(textoVisor);
    }

    public void Apagar(View view){
        txtVisor.setText("0");

        numeroAtual = 0f;
        numeroAnterior = 0f;
        resultado = 0f;
    }

    public  void btnOperacao(View view){

        Button btnOp = (Button) view;

        switch (btnOp.getId()){
            case R.id.btnAdi:
                if(numeroAnterior == 0){
                    numeroAnterior = numeroAtual;
                    txtVisor.setText("0");
                } else {
                    numeroAnterior += numeroAtual;
                    txtVisor.setText(String.valueOf(numeroAnterior));
                }
                numeroAtual = 0f;
                txtVisor.setText("0");
                op = "Adic";
                break;

            case R.id.btnSub:

                break;

            case R.id.btnMul:

                break;

            case R.id.btnDiv:

                break;

            case R.id.btnIgual:
                Float result;

                if(op.equals("Adic")){
                    result = numeroAnterior + numeroAtual;
                    resultado += result;
                    numeroAnterior = 0f;
                    numeroAtual = 0f;
                    txtVisor.setText(String.valueOf(resultado));
                }
                break;
        }
    }

}
